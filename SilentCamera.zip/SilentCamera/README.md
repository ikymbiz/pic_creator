# SilentCamera

無音カメラアプリ（動物・赤ちゃん撮影用 / 暗号化保存対応）

## 機能

- 完全無音でのシャッター撮影（ImageAnalysis方式）
- **物理キー対応**：音量上下ボタン・カメラキーで撮影
- **連写モード**：SHOTボタン長押しで 4連写/秒
- **タップフォーカス**：画面タップでピント合わせ
- **前面/背面カメラ切替**
- **自動回転補正**
- **AES256-GCM暗号化保存**（AndroidKeystore管理）

## セットアップ方法

### 1. Android Studioで新規プロジェクトを作成

1. Android Studio を起動
2. 「New Project」→「Empty Views Activity」を選択
3. 以下の設定で作成：
   - Name: `SilentCamera`
   - Package name: `com.example.silentcamera`
   - Language: `Kotlin`
   - Minimum SDK: `API 24`

### 2. ファイルを上書き

作成したプロジェクトに、このzip内の以下ファイルを上書きコピーしてください：

| このzip内のパス | プロジェクト内のパス |
|---|---|
| `app/build.gradle` | `app/build.gradle` |
| `app/src/main/AndroidManifest.xml` | `app/src/main/AndroidManifest.xml` |
| `app/src/main/java/com/example/silentcamera/MainActivity.kt` | `app/src/main/java/com/example/silentcamera/MainActivity.kt` |
| `app/src/main/res/layout/activity_main.xml` | `app/src/main/res/layout/activity_main.xml` |
| `app/src/main/res/values/strings.xml` | `app/src/main/res/values/strings.xml` |

### 3. Gradle Sync → 実機で実行

「Sync Now」をクリックしてライブラリをダウンロード後、実機にインストールしてください。

## 操作方法

| 操作 | 動作 |
|---|---|
| SHOTボタンをタップ | 1枚撮影 |
| SHOTボタンを長押し | 4連写/秒（指を離すまで） |
| 音量上 / 音量下 / カメラキー | 1枚撮影 |
| 「切替」ボタン | 前面/背面カメラ切替 |
| プレビュー画面をタップ | その位置にピント合わせ |

## 保存先

`/data/data/com.example.silentcamera/files/secure_images/` に `.jpg.enc` として保存されます。

## 画像の復号方法（別画面で表示する場合）

```kotlin
import android.graphics.BitmapFactory
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey

fun decryptToBitmap(context: Context, file: File, masterKey: MasterKey): Bitmap? {
    val encryptedFile = EncryptedFile.Builder(
        context, file, masterKey,
        EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
    ).build()

    return encryptedFile.openFileInput().use { input ->
        val bytes = input.readBytes()
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }
}
```

## ⚠️ 重要な注意

1. **端末を初期化すると復号不能になります**。マスターキーがAndroid Keystoreごと消えるため、必要な写真はクラウドバックアップを併用してください。
2. **音量キーの横取り**はこのActivityが表示中のみ有効です。
3. 撮影画像は ImageAnalysis 経由のため、解像度は端末依存（通常 4〜8MP 相当）です。
