package com.example.silentcamera

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeleteSliderActivity : AppCompatActivity() {

    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var clockText: TextView
    private lateinit var dateText: TextView

    private val clockTick = object : Runnable {
        override fun run() {
            updateClock()
            // 次の「00秒」まで待って再実行
            val now = System.currentTimeMillis()
            val nextMinute = 60_000L - (now % 60_000L)
            uiHandler.postDelayed(this, nextMinute)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_delete_slider)
        window.statusBarColor = Color.BLACK

        clockText = findViewById(R.id.clockText)
        dateText = findViewById(R.id.dateText)
        updateClock()

        val track = findViewById<FrameLayout>(R.id.sliderTrack)
        val handle = findViewById<View>(R.id.sliderHandle)
        val hint = findViewById<TextView>(R.id.hintText)

        track.viewTreeObserver.addOnGlobalLayoutListener(object :
            ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                track.viewTreeObserver.removeOnGlobalLayoutListener(this)
                setupSlider(track, handle, hint)
            }
        })
    }

    private fun updateClock() {
        val now = Date()
        val timeFmt = SimpleDateFormat("H:mm", Locale.getDefault())
        val dateFmt = SimpleDateFormat("M月d日（E）", Locale.JAPANESE)
        clockText.text = timeFmt.format(now)
        dateText.text = dateFmt.format(now)
    }

    override fun onResume() {
        super.onResume()
        uiHandler.post(clockTick)
    }

    override fun onPause() {
        super.onPause()
        uiHandler.removeCallbacks(clockTick)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupSlider(track: FrameLayout, handle: View, hint: TextView) {
        val maxX = (track.width - handle.width).toFloat()
        if (maxX <= 0) return

        var startX = 0f
        var startHandleX = 0f

        handle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    startHandleX = handle.translationX
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startX
                    val newX = (startHandleX + dx).coerceIn(0f, maxX)
                    handle.translationX = newX
                    hint.alpha = 1f - (newX / maxX)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (handle.translationX >= maxX * 0.95f) {
                        performDelete()
                    } else {
                        animateBack(handle, hint)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun animateBack(handle: View, hint: TextView) {
        ValueAnimator.ofFloat(handle.translationX, 0f).apply {
            duration = 200
            addUpdateListener {
                val v = it.animatedValue as Float
                handle.translationX = v
                val track = findViewById<FrameLayout>(R.id.sliderTrack)
                val maxX = (track.width - handle.width).toFloat()
                if (maxX > 0) hint.alpha = 1f - (v / maxX)
            }
            start()
        }
    }

    private fun performDelete() {
        File(filesDir, "secure_images").listFiles()?.forEach { it.delete() }
        File(filesDir, "secure_videos").listFiles()?.forEach { it.delete() }
        File(filesDir, "pending_videos").listFiles()?.forEach { it.delete() }
        finish()
    }
}

