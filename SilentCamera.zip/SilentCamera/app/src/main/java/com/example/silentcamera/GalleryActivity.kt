package com.example.silentcamera

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ImageView
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class GalleryActivity : AppCompatActivity() {

    private lateinit var masterKey: MasterKey
    private lateinit var executor: ExecutorService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)
        window.statusBarColor = Color.parseColor("#4CAF50")

        masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        executor = Executors.newFixedThreadPool(2)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val emptyText = findViewById<TextView>(R.id.emptyText)

        // 画像と動画を集めて、新しい順にマージ
        val imageFiles = File(filesDir, "secure_images")
            .listFiles { f -> f.name.endsWith(".jpg.enc") }?.toList() ?: emptyList()
        val videoFiles = File(filesDir, "secure_videos")
            .listFiles { f -> f.name.endsWith(".mp4.enc") }?.toList() ?: emptyList()
        val allFiles = (imageFiles + videoFiles)
            .sortedByDescending { it.lastModified() }

        if (allFiles.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyText.visibility = View.VISIBLE
        } else {
            recyclerView.layoutManager = GridLayoutManager(this, 3)
            recyclerView.adapter = MediaAdapter(allFiles, masterKey, executor) { file ->
                if (file.name.endsWith(".mp4.enc")) {
                    playVideo(file)
                } else {
                    showFullImage(file)
                }
            }
        }
    }

    private fun showFullImage(file: File) {
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_full_image)
        val imageView = dialog.findViewById<ImageView>(R.id.fullImage)
        imageView.setOnClickListener { dialog.dismiss() }

        executor.execute {
            val bitmap = decryptFullImage(this, file, masterKey)
            runOnUiThread {
                if (bitmap != null) {
                    imageView.setImageBitmap(bitmap)
                    dialog.show()
                }
            }
        }
    }

    private fun playVideo(file: File) {
        executor.execute {
            val tempFile = decryptVideoToTemp(file) ?: return@execute
            runOnUiThread {
                val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                dialog.setContentView(R.layout.dialog_video)
                val videoView = dialog.findViewById<VideoView>(R.id.videoView)

                val controller = MediaController(this)
                controller.setAnchorView(videoView)
                videoView.setMediaController(controller)
                videoView.setVideoURI(Uri.fromFile(tempFile))

                videoView.setOnPreparedListener { it.isLooping = false }
                videoView.setOnCompletionListener { /* そのまま閉じられるように */ }

                dialog.setOnDismissListener {
                    videoView.stopPlayback()
                    tempFile.delete() // 復号した一時ファイルを削除
                }

                dialog.show()
                videoView.start()
            }
        }
    }

    private fun decryptVideoToTemp(file: File): File? {
        return try {
            val ef = EncryptedFile.Builder(
                this, file, masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()
            val bytes = ef.openFileInput().use { it.readBytes() }
            val tmp = File.createTempFile("play_", ".mp4", cacheDir)
            tmp.writeBytes(bytes)
            tmp
        } catch (e: Exception) {
            null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
        // キャッシュ内の一時ファイルをクリーンアップ
        cacheDir.listFiles { f -> f.name.startsWith("play_") }?.forEach { it.delete() }
    }

    companion object {
        fun decryptThumbnail(ctx: Context, file: File, key: MasterKey): Bitmap? {
            return try {
                val ef = EncryptedFile.Builder(
                    ctx, file, key,
                    EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
                ).build()
                val bytes = ef.openFileInput().use { it.readBytes() }

                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)

                var sample = 1
                while (bounds.outWidth / sample > 400 || bounds.outHeight / sample > 400) {
                    sample *= 2
                }
                val opt = BitmapFactory.Options().apply { inSampleSize = sample }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opt)
            } catch (e: Exception) {
                null
            }
        }

        fun decryptFullImage(ctx: Context, file: File, key: MasterKey): Bitmap? {
            return try {
                val ef = EncryptedFile.Builder(
                    ctx, file, key,
                    EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
                ).build()
                val bytes = ef.openFileInput().use { it.readBytes() }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Exception) {
                null
            }
        }
    }
}

class MediaAdapter(
    private val files: List<File>,
    private val masterKey: MasterKey,
    private val executor: ExecutorService,
    private val onClick: (File) -> Unit
) : RecyclerView.Adapter<MediaAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val imageView: ImageView = v.findViewById(R.id.imageView)
        val videoBadge: TextView = v.findViewById(R.id.videoBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_image, parent, false)
        return VH(v)
    }

    override fun getItemCount() = files.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val file = files[position]
        val isVideo = file.name.endsWith(".mp4.enc")
        val ctx = holder.itemView.context

        holder.imageView.setImageBitmap(null)
        holder.videoBadge.visibility = if (isVideo) View.VISIBLE else View.GONE

        if (!isVideo) {
            executor.execute {
                val bmp = GalleryActivity.decryptThumbnail(ctx, file, masterKey)
                holder.imageView.post {
                    holder.imageView.setImageBitmap(bmp)
                }
            }
        }

        holder.itemView.setOnClickListener { onClick(file) }
    }
}
