package com.example.silentcamera

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * 録画中にプロセスをkillされないよう維持するためだけのフォアグラウンドサービス。
 * 通知は最小限の見た目で表示される（Androidの仕様上、通知は必須）。
 *
 * MainActivityが録画を開始するときに起動され、録画停止時に停止される。
 */
class RecordingKeepaliveService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()

        // 極力目立たない通知
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            // 小さいアイコンは必須。なるべく目立たないシステムアイコンを使用
            .setSmallIcon(android.R.drawable.presence_invisible)
            .setContentTitle(" ")  // 空白1文字（空にすると「???」になる機種があるため）
            .setContentText(" ")
            .setPriority(NotificationCompat.PRIORITY_MIN)  // 最小優先度
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)  // ロック画面非表示
            .setOngoing(true)
            .setSilent(true)  // 音・バイブなし
            .setShowWhen(false)
            .build()

        startForeground(NOTIFICATION_ID, notification)
        // サービスが殺された場合は再起動しない（録画自体はActivityが管理するため）
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                " ", // チャンネル名も最小限（設定画面に表示されるが空白に近い）
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = ""
                setShowBadge(false)  // ランチャーバッジ非表示
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val CHANNEL_ID = "nothing_keepalive"
        private const val NOTIFICATION_ID = 101

        fun start(context: Context) {
            val intent = Intent(context, RecordingKeepaliveService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, RecordingKeepaliveService::class.java))
        }
    }
}
