package com.example.silentcamera

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var viewFinder: PreviewView
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var masterKey: MasterKey
    private lateinit var topBar: View
    private lateinit var recIndicator: View
    private lateinit var previewCover: android.widget.FrameLayout
    private lateinit var prefs: android.content.SharedPreferences

    private var clockTickRunnable: Runnable? = null
    private var clockText: TextView? = null
    private var dateText: TextView? = null

    private var isCapturePending = false
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var currentRecording: Recording? = null
    private var currentVideoFile: File? = null
    private var isRecording = false
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var screenMode = SCREEN_MODE_PREVIEW  // 0=プレビュー, 1=オフ, 2=時計
    private var barColor = DEFAULT_BAR_COLOR
    private var autoRecord = false
    private var maxRecMinutes = 0 // 0 = 無制限
    private var autoRecordTriggered = false // 起動時の自動録画が既に発動済みか

    private val uiHandler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("silentcam", Context.MODE_PRIVATE)
        barColor = prefs.getInt(KEY_BAR_COLOR, DEFAULT_BAR_COLOR)
        screenMode = prefs.getInt(KEY_SCREEN_MODE, SCREEN_MODE_PREVIEW)
        autoRecord = prefs.getBoolean(KEY_AUTO_RECORD, false)
        maxRecMinutes = prefs.getInt(KEY_MAX_REC_MIN, 0)

        viewFinder = findViewById(R.id.viewFinder)
        topBar = findViewById(R.id.topBar)
        recIndicator = findViewById(R.id.recIndicator)
        previewCover = findViewById(R.id.previewCover)

        applyBarColor(barColor)
        applyScreenMode()

        masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        if (allPermissionsGranted()) startCamera()
        else ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)

        // 緑バーをタップ → 設定メニュー
        topBar.setOnClickListener { showSettingsMenu() }

        // プレビューをタップ → フォーカス
        viewFinder.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val point = viewFinder.meteringPointFactory.createPoint(event.x, event.y)
                camera?.cameraControl?.startFocusAndMetering(
                    FocusMeteringAction.Builder(point).build()
                )
            }
            true
        }

        cameraExecutor = Executors.newSingleThreadExecutor()

        // 前回異常終了時の未暗号化動画を自動復旧
        cameraExecutor.execute { recoverPendingVideos() }
        // 6時間経過した古いファイルを自動削除
        cameraExecutor.execute { purgeOldFiles() }
    }

    /**
     * 6時間以上経過したファイルを自動削除。容量節約のため。
     * ダウンロードしたい画像・動画は6時間以内にギャラリー画面から取り出す必要がある。
     */
    private fun purgeOldFiles() {
        val sixHoursMs = 6L * 60L * 60L * 1000L
        val cutoff = System.currentTimeMillis() - sixHoursMs
        var purged = 0
        listOf("secure_images", "secure_videos", "pending_videos").forEach { dirName ->
            val dir = File(filesDir, dirName)
            if (!dir.exists()) return@forEach
            dir.listFiles()?.forEach { f ->
                if (f.lastModified() < cutoff) {
                    if (f.delete()) purged++
                }
            }
        }
        if (purged > 0) Log.i(TAG, "Auto-purged $purged old file(s)")
    }

    /**
     * pending_videos/ に残っている平文mp4を検出し、暗号化してsecure_videos/に移動する。
     * 自動録画中にクラッシュや強制終了が起きても、次回起動時にここで拾える。
     */
    private fun recoverPendingVideos() {
        val pendingDir = File(filesDir, "pending_videos")
        if (!pendingDir.exists()) return
        val orphans = pendingDir.listFiles { f -> f.name.endsWith(".mp4") } ?: return
        if (orphans.isEmpty()) return

        Log.i(TAG, "Recovering ${orphans.size} orphan video(s)")
        orphans.forEach { file ->
            try {
                encryptVideoFile(file)
            } catch (e: Exception) {
                Log.e(TAG, "Recovery failed for ${file.name}", e)
            }
        }
    }

    private fun applyBarColor(color: Int) {
        topBar.setBackgroundColor(color)
        window.statusBarColor = color
    }

    private fun applyScreenMode() {
        // 一旦クリーンアップ
        previewCover.removeAllViews()
        stopClockTicker()

        when (screenMode) {
            SCREEN_MODE_PREVIEW -> {
                previewCover.visibility = View.GONE
            }
            SCREEN_MODE_OFF -> {
                previewCover.visibility = View.VISIBLE
                // 黒画面のみ（何も追加しない）
            }
            SCREEN_MODE_CLOCK -> {
                previewCover.visibility = View.VISIBLE
                val inflater = layoutInflater
                val clockView = inflater.inflate(R.layout.clock_overlay, previewCover, false)
                previewCover.addView(clockView)
                clockText = clockView.findViewById(R.id.clockText)
                dateText = clockView.findViewById(R.id.dateText)
                setupLockSlider(clockView)
                startClockTicker()
            }
        }
    }

    private fun startClockTicker() {
        updateClockDisplay()
        val tick = object : Runnable {
            override fun run() {
                updateClockDisplay()
                val now = System.currentTimeMillis()
                val nextMinute = 60_000L - (now % 60_000L)
                uiHandler.postDelayed(this, nextMinute)
            }
        }
        clockTickRunnable = tick
        val now = System.currentTimeMillis()
        val nextMinute = 60_000L - (now % 60_000L)
        uiHandler.postDelayed(tick, nextMinute)
    }

    private fun stopClockTicker() {
        clockTickRunnable?.let { uiHandler.removeCallbacks(it) }
        clockTickRunnable = null
    }

    private fun updateClockDisplay() {
        val now = java.util.Date()
        val timeFmt = java.text.SimpleDateFormat("H:mm", java.util.Locale.getDefault())
        val dateFmt = java.text.SimpleDateFormat("M月d日（E）", java.util.Locale.JAPANESE)
        clockText?.text = timeFmt.format(now)
        dateText?.text = dateFmt.format(now)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupLockSlider(root: View) {
        val track = root.findViewById<android.widget.FrameLayout>(R.id.sliderTrack)
        val handle = root.findViewById<View>(R.id.sliderHandle)

        track.viewTreeObserver.addOnGlobalLayoutListener(object :
            android.view.ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                track.viewTreeObserver.removeOnGlobalLayoutListener(this)
                // ハンドルの上下マージンも考慮（レイアウトの layout_margin=4dp 分）
                val maxY = (track.height - handle.height - 8).toFloat()
                if (maxY <= 0) return

                var startY = 0f
                var startHandleY = 0f

                handle.setOnTouchListener { _, event ->
                    when (event.action) {
                        MotionEvent.ACTION_DOWN -> {
                            startY = event.rawY
                            startHandleY = handle.translationY
                            true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dy = event.rawY - startY
                            // 上方向（負の方向）にのみ動かす。0 〜 -maxY
                            val newY = (startHandleY + dy).coerceIn(-maxY, 0f)
                            handle.translationY = newY
                            true
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            // 上端から5%以内まで到達したら発動
                            if (-handle.translationY >= maxY * 0.95f) {
                                performDeleteAll()
                            } else {
                                animateSliderBack(handle)
                            }
                            true
                        }
                        else -> false
                    }
                }
            }
        })
    }

    private fun animateSliderBack(handle: View) {
        android.animation.ValueAnimator.ofFloat(handle.translationY, 0f).apply {
            duration = 200
            addUpdateListener {
                handle.translationY = it.animatedValue as Float
            }
            start()
        }
    }

    private fun performDeleteAll() {
        // 録画中なら停止
        if (isRecording) {
            try { currentRecording?.stop() } catch (_: Exception) {}
        }
        // 全データ削除
        File(filesDir, "secure_images").listFiles()?.forEach { it.delete() }
        File(filesDir, "secure_videos").listFiles()?.forEach { it.delete() }
        File(filesDir, "pending_videos").listFiles()?.forEach { it.delete() }
        // アプリ完全終了
        finishAffinity()
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    private fun showSettingsMenu() {
        val cameraLabel = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            "カメラ切替（現在: 背面）" else "カメラ切替（現在: 前面）"
        val screenLabel = "画面モード: " + when (screenMode) {
            SCREEN_MODE_PREVIEW -> "プレビュー"
            SCREEN_MODE_OFF -> "オフ"
            SCREEN_MODE_CLOCK -> "時計"
            else -> "プレビュー"
        }
        val autoRecLabel = if (autoRecord)
            "起動時に自動録画: オン" else "起動時に自動録画: オフ"
        val maxRecLabel = when (maxRecMinutes) {
            0 -> "最大録画時間: 無制限"
            else -> "最大録画時間: ${maxRecMinutes}分"
        }
        val recordControlLabel = if (isRecording) "■ 録画を停止" else "● 録画を開始"

        val items = arrayOf(
            "撮影した画像・動画を見る",
            recordControlLabel,
            cameraLabel,
            screenLabel,
            autoRecLabel,
            maxRecLabel,
            "バーの色を選ぶ"
        )
        AlertDialog.Builder(this)
            .setTitle("設定")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, GalleryActivity::class.java))
                    1 -> toggleRecording()
                    2 -> switchCamera()
                    3 -> showScreenModePicker()
                    4 -> toggleAutoRecord()
                    5 -> showMaxRecTimePicker()
                    6 -> showColorPicker()
                }
            }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun showScreenModePicker() {
        val options = arrayOf("プレビュー（カメラ映像）", "オフ（黒画面）", "時計")
        AlertDialog.Builder(this)
            .setTitle("画面モード")
            .setSingleChoiceItems(options, screenMode) { dialog, which ->
                screenMode = which
                prefs.edit().putInt(KEY_SCREEN_MODE, screenMode).apply()
                applyScreenMode()
                dialog.dismiss()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun toggleRecording() {
        if (isRecording) stopRecording() else startRecording()
    }

    private fun toggleAutoRecord() {
        autoRecord = !autoRecord
        prefs.edit().putBoolean(KEY_AUTO_RECORD, autoRecord).apply()
    }

    private fun showMaxRecTimePicker() {
        val options = arrayOf("無制限", "5分", "15分", "30分", "60分")
        val values = intArrayOf(0, 5, 15, 30, 60)
        val current = values.indexOf(maxRecMinutes).coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle("最大録画時間")
            .setSingleChoiceItems(options, current) { dialog, which ->
                maxRecMinutes = values[which]
                prefs.edit().putInt(KEY_MAX_REC_MIN, maxRecMinutes).apply()
                dialog.dismiss()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    private fun showColorPicker() {
        val colors = listOf(
            "#3DDC84" to "① Android緑（#3DDC84）",
            "#4CAF50" to "② Material 500（標準）",
            "#66BB6A" to "③ 少し明るい（Green 400）",
            "#81C784" to "④ もっと明るい（Green 300）",
            "#8BC34A" to "⑤ 黄緑寄り（Light Green 500）",
            "#9CCC65" to "⑥ 鮮やかな黄緑（Light Green 400）"
        )

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
        }

        colors.forEach { (hex, label) ->
            val row = TextView(this).apply {
                text = label
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(32, 40, 32, 40)
                gravity = Gravity.CENTER_VERTICAL
                background = ColorDrawable(Color.parseColor(hex))
                setOnClickListener {
                    val c = Color.parseColor(hex)
                    barColor = c
                    prefs.edit().putInt(KEY_BAR_COLOR, c).apply()
                    applyBarColor(c)
                }
            }
            container.addView(row)
            // 行間スペーサー
            val spacer = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 8
                )
            }
            container.addView(spacer)
        }

        AlertDialog.Builder(this)
            .setTitle("バーの色を選んでタップ")
            .setView(container)
            .setPositiveButton("閉じる", null)
            .show()
    }

    private fun switchCamera() {
        if (isRecording) return
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    // 音量キー: 短押しで写真、長押しで動画
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_DOWN,
            KeyEvent.KEYCODE_VOLUME_UP,
            KeyEvent.KEYCODE_CAMERA -> {
                if (event != null && event.repeatCount == 0) {
                    // 最初の押下: 600ms後に動画開始するタイマーを仕掛ける
                    longPressRunnable = Runnable { startRecording() }
                    uiHandler.postDelayed(longPressRunnable!!, 600)
                }
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_DOWN,
            KeyEvent.KEYCODE_VOLUME_UP,
            KeyEvent.KEYCODE_CAMERA -> {
                longPressRunnable?.let { uiHandler.removeCallbacks(it) }
                longPressRunnable = null
                if (isRecording) {
                    stopRecording()
                } else {
                    // タイマー発火前に離した → 写真1枚
                    isCapturePending = true
                }
                true
            }
            else -> super.onKeyUp(keyCode, event)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }

            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                if (isCapturePending && !isRecording) {
                    isCapturePending = false
                    val rotation = imageProxy.imageInfo.rotationDegrees
                    val bitmap = rotateBitmap(imageProxy.toBitmap(), rotation)
                    saveEncryptedImage(bitmap)
                }
                imageProxy.close()
            }

            // 動画撮影用Recorder
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        Quality.HD,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                )
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            val cameraSelector = CameraSelector.Builder()
                .requireLensFacing(lensFacing).build()

            try {
                cameraProvider?.unbindAll()
                // Preview + ImageAnalysis + VideoCapture 同時bind
                camera = cameraProvider?.bindToLifecycle(
                    this, cameraSelector, preview, imageAnalysis, videoCapture
                )
                maybeAutoStartRecording()
            } catch (e: Exception) {
                Log.e(TAG, "Full binding failed, fallback to preview+video", e)
                // 失敗したらImageAnalysisなしで再試行（古い端末対応）
                try {
                    cameraProvider?.unbindAll()
                    camera = cameraProvider?.bindToLifecycle(
                        this, cameraSelector, preview, videoCapture
                    )
                    maybeAutoStartRecording()
                } catch (e2: Exception) {
                    Log.e(TAG, "Fallback binding also failed", e2)
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun maybeAutoStartRecording() {
        if (autoRecord && !autoRecordTriggered && !isRecording) {
            autoRecordTriggered = true
            // カメラ準備直後は不安定なので少し遅延
            uiHandler.postDelayed({
                if (!isRecording) startRecording()
            }, 800)
        }
    }

    private fun startRecording() {
        val vc = videoCapture ?: return
        if (isRecording) return

        val dir = File(filesDir, "pending_videos").apply { if (!exists()) mkdirs() }
        val tempFile = File(dir, "VID_${System.currentTimeMillis()}.mp4")
        currentVideoFile = tempFile

        val output = FileOutputOptions.Builder(tempFile).build()
        val hasAudio = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val pending = vc.output.prepareRecording(this, output)
        if (hasAudio) {
            enableAudioSafely(pending)
        }

        currentRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    isRecording = true
                    recIndicator.visibility = View.VISIBLE
                    // 最大録画時間タイマー
                    if (maxRecMinutes > 0) {
                        uiHandler.postDelayed({
                            if (isRecording) stopRecording()
                        }, maxRecMinutes * 60_000L)
                    }
                }
                is VideoRecordEvent.Finalize -> {
                    isRecording = false
                    recIndicator.visibility = View.GONE
                    if (event.hasError()) {
                        Log.e(TAG, "Recording error: ${event.error}")
                        tempFile.delete()
                    } else {
                        // 録画完了 → 暗号化保存
                        cameraExecutor.execute { encryptVideoFile(tempFile) }
                    }
                    currentRecording = null
                    currentVideoFile = null
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableAudioSafely(pending: PendingRecording) {
        try {
            pending.withAudioEnabled()
        } catch (e: Exception) {
            Log.w(TAG, "Audio enable failed", e)
        }
    }

    private fun stopRecording() {
        currentRecording?.stop()
    }

    private fun encryptVideoFile(videoFile: File) {
        try {
            if (!videoFile.exists() || videoFile.length() == 0L) {
                videoFile.delete()
                return
            }
            val bytes = videoFile.readBytes()
            val secureDir = File(filesDir, "secure_videos").apply {
                if (!exists()) mkdirs()
            }
            val encFile = File(secureDir, "${videoFile.nameWithoutExtension}.mp4.enc")
            val ef = EncryptedFile.Builder(
                this, encFile, masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()
            ef.openFileOutput().use { it.write(bytes) }
            // 暗号化成功 → 平文削除
            videoFile.delete()
        } catch (e: Exception) {
            Log.e(TAG, "Encrypt video failed", e)
            // 失敗時は平文を残す。次回起動時のリカバリで再試行される
        }
    }

    private fun rotateBitmap(src: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return src
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    private fun saveEncryptedImage(bitmap: Bitmap) {
        try {
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, baos)
            val jpegBytes = baos.toByteArray()

            val dir = File(filesDir, "secure_images").apply { if (!exists()) mkdirs() }
            val file = File(dir, "IMG_${System.currentTimeMillis()}.jpg.enc")

            val encryptedFile = EncryptedFile.Builder(
                this, file, masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            encryptedFile.openFileOutput().use { out ->
                out.write(jpegBytes)
                out.flush()
            }

        } catch (e: Exception) {
            Log.e(TAG, "Encrypt failed", e)
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            // カメラ権限が取れていれば起動（マイクは任意）
            val cameraGranted = ContextCompat.checkSelfPermission(
                baseContext, Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            if (cameraGranted) startCamera()
            else finish()
        }
    }

    override fun onStart() {
        super.onStart()
        // 時計モードなら表示を更新（画面復帰時の即時反映用）
        if (screenMode == SCREEN_MODE_CLOCK && clockTickRunnable == null) {
            startClockTicker()
        }
    }

    override fun onStop() {
        super.onStop()
        // バックグラウンド移行時に録画停止
        if (isRecording) stopRecording()
        stopClockTicker()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    companion object {
        private const val TAG = "SilentCamera"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        private const val KEY_BAR_COLOR = "bar_color"
        private const val KEY_SCREEN_MODE = "screen_mode"
        private const val KEY_AUTO_RECORD = "auto_record"
        private const val KEY_MAX_REC_MIN = "max_rec_min"
        private val DEFAULT_BAR_COLOR = Color.parseColor("#3DDC84")

        private const val SCREEN_MODE_PREVIEW = 0
        private const val SCREEN_MODE_OFF = 1
        private const val SCREEN_MODE_CLOCK = 2
    }
}
