package com.example.silentcamera

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var viewFinder: PreviewView
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var masterKey: MasterKey
    private lateinit var topBar: View
    private lateinit var topBarText: TextView
    private lateinit var previewCover: View
    private lateinit var prefs: android.content.SharedPreferences

    private var isCapturePending = false
    private var camera: Camera? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var currentRecording: Recording? = null
    private var currentVideoFile: File? = null
    private var isRecording = false
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var previewVisible = true
    private var barColor = DEFAULT_BAR_COLOR

    private val uiHandler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("silentcam", Context.MODE_PRIVATE)
        barColor = prefs.getInt(KEY_BAR_COLOR, DEFAULT_BAR_COLOR)
        previewVisible = prefs.getBoolean(KEY_PREVIEW_VISIBLE, true)

        viewFinder = findViewById(R.id.viewFinder)
        topBar = findViewById(R.id.topBar)
        topBarText = findViewById(R.id.topBarText)
        previewCover = findViewById(R.id.previewCover)

        applyBarColor(barColor)
        applyPreviewVisibility()

        masterKey = MasterKey.Builder(this)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        if (allPermissionsGranted()) startCamera()
        else ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)

        // 緑バーをタップ → 設定メニュー
        topBar.setOnClickListener { showSettingsMenu() }

        // プレビューをタップ → フォーカス
        viewFinder.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val point = viewFinder.meteringPointFactory.createPoint(event.x, event.y)
                camera?.cameraControl?.startFocusAndMetering(
                    FocusMeteringAction.Builder(point).build()
                )
            }
            true
        }

        cameraExecutor = Executors.newSingleThreadExecutor()
    }

    private fun applyBarColor(color: Int) {
        topBar.setBackgroundColor(color)
        window.statusBarColor = color
    }

    private fun applyPreviewVisibility() {
        previewCover.visibility = if (previewVisible) View.GONE else View.VISIBLE
    }

    private fun showSettingsMenu() {
        val cameraLabel = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            "カメラ切替（現在: 背面）" else "カメラ切替（現在: 前面）"
        val previewLabel = if (previewVisible)
            "プレビュー: オン" else "プレビュー: オフ"
        val items = arrayOf(
            "撮影した画像・動画を見る",
            cameraLabel,
            previewLabel,
            "バーの色を選ぶ",
            "全データを削除"
        )
        AlertDialog.Builder(this)
            .setTitle("設定")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, GalleryActivity::class.java))
                    1 -> switchCamera()
                    2 -> togglePreview()
                    3 -> showColorPicker()
                    4 -> confirmDeleteAll()
                }
            }
            .setNegativeButton("閉じる", null)
            .show()
    }

    private fun togglePreview() {
        previewVisible = !previewVisible
        prefs.edit().putBoolean(KEY_PREVIEW_VISIBLE, previewVisible).apply()
        applyPreviewVisibility()
        val msg = if (previewVisible) "プレビューをオンにしました" else "プレビューをオフにしました"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun showColorPicker() {
        val colors = listOf(
            "#4CAF50" to "① 現在の緑（Material 500）",
            "#66BB6A" to "② 少し明るい（Green 400）",
            "#81C784" to "③ もっと明るい（Green 300）",
            "#8BC34A" to "④ 黄緑寄り（Light Green 500）",
            "#9CCC65" to "⑤ 鮮やかな黄緑（Light Green 400）"
        )

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
        }

        colors.forEach { (hex, label) ->
            val row = TextView(this).apply {
                text = label
                textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(32, 40, 32, 40)
                gravity = Gravity.CENTER_VERTICAL
                background = ColorDrawable(Color.parseColor(hex))
                setOnClickListener {
                    val c = Color.parseColor(hex)
                    barColor = c
                    prefs.edit().putInt(KEY_BAR_COLOR, c).apply()
                    applyBarColor(c)
                    Toast.makeText(this@MainActivity, "バーの色を変更しました", Toast.LENGTH_SHORT).show()
                }
            }
            container.addView(row)
            // 行間スペーサー
            val spacer = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 8
                )
            }
            container.addView(spacer)
        }

        AlertDialog.Builder(this)
            .setTitle("バーの色を選んでタップ")
            .setView(container)
            .setPositiveButton("閉じる", null)
            .show()
    }

    private fun switchCamera() {
        if (isRecording) {
            Toast.makeText(this, "録画中は切り替えできません", Toast.LENGTH_SHORT).show()
            return
        }
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        val label = if (lensFacing == CameraSelector.LENS_FACING_BACK) "背面カメラ" else "前面カメラ"
        Toast.makeText(this, label, Toast.LENGTH_SHORT).show()
        startCamera()
    }

    private fun confirmDeleteAll() {
        AlertDialog.Builder(this)
            .setTitle("確認")
            .setMessage("すべての画像と動画を削除しますか？この操作は取り消せません。")
            .setPositiveButton("削除") { _, _ ->
                var count = 0
                File(filesDir, "secure_images").listFiles()?.forEach { it.delete(); count++ }
                File(filesDir, "secure_videos").listFiles()?.forEach { it.delete(); count++ }
                Toast.makeText(this, "${count}件削除しました", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("キャンセル", null)
            .show()
    }

    // 音量キー: 短押しで写真、長押しで動画
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_DOWN,
            KeyEvent.KEYCODE_VOLUME_UP,
            KeyEvent.KEYCODE_CAMERA -> {
                if (event != null && event.repeatCount == 0) {
                    // 最初の押下: 600ms後に動画開始するタイマーを仕掛ける
                    longPressRunnable = Runnable { startRecording() }
                    uiHandler.postDelayed(longPressRunnable!!, 600)
                }
                true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_DOWN,
            KeyEvent.KEYCODE_VOLUME_UP,
            KeyEvent.KEYCODE_CAMERA -> {
                longPressRunnable?.let { uiHandler.removeCallbacks(it) }
                longPressRunnable = null
                if (isRecording) {
                    stopRecording()
                } else {
                    // タイマー発火前に離した → 写真1枚
                    isCapturePending = true
                }
                true
            }
            else -> super.onKeyUp(keyCode, event)
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }

            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                if (isCapturePending && !isRecording) {
                    isCapturePending = false
                    val rotation = imageProxy.imageInfo.rotationDegrees
                    val bitmap = rotateBitmap(imageProxy.toBitmap(), rotation)
                    saveEncryptedImage(bitmap)
                }
                imageProxy.close()
            }

            // 動画撮影用Recorder
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        Quality.HD,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                )
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            val cameraSelector = CameraSelector.Builder()
                .requireLensFacing(lensFacing).build()

            try {
                cameraProvider?.unbindAll()
                // Preview + ImageAnalysis + VideoCapture 同時bind
                camera = cameraProvider?.bindToLifecycle(
                    this, cameraSelector, preview, imageAnalysis, videoCapture
                )
            } catch (e: Exception) {
                Log.e(TAG, "Full binding failed, fallback to preview+video", e)
                // 失敗したらImageAnalysisなしで再試行（古い端末対応）
                try {
                    cameraProvider?.unbindAll()
                    camera = cameraProvider?.bindToLifecycle(
                        this, cameraSelector, preview, videoCapture
                    )
                    Toast.makeText(this, "この端末は無音写真機能が制限されます", Toast.LENGTH_LONG).show()
                } catch (e2: Exception) {
                    Log.e(TAG, "Fallback binding also failed", e2)
                }
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startRecording() {
        val vc = videoCapture ?: return
        if (isRecording) return

        val dir = File(filesDir, "secure_videos").apply { if (!exists()) mkdirs() }
        val tempFile = File(dir, "VID_${System.currentTimeMillis()}.mp4")
        currentVideoFile = tempFile

        val output = FileOutputOptions.Builder(tempFile).build()
        val hasAudio = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val pending = vc.output.prepareRecording(this, output)
        if (hasAudio) {
            enableAudioSafely(pending)
        }

        currentRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    isRecording = true
                    topBarText.text = "● 録画中"
                    topBarText.setTextColor(Color.parseColor("#FFCDD2"))
                }
                is VideoRecordEvent.Finalize -> {
                    isRecording = false
                    topBarText.text = "SilentCamera"
                    topBarText.setTextColor(Color.WHITE)
                    if (event.hasError()) {
                        Log.e(TAG, "Recording error: ${event.error}")
                        tempFile.delete()
                        Toast.makeText(this, "録画失敗", Toast.LENGTH_SHORT).show()
                    } else {
                        // 録画完了 → 暗号化保存
                        cameraExecutor.execute { encryptVideoFile(tempFile) }
                    }
                    currentRecording = null
                    currentVideoFile = null
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun enableAudioSafely(pending: PendingRecording) {
        try {
            pending.withAudioEnabled()
        } catch (e: Exception) {
            Log.w(TAG, "Audio enable failed", e)
        }
    }

    private fun stopRecording() {
        currentRecording?.stop()
    }

    private fun encryptVideoFile(videoFile: File) {
        try {
            if (!videoFile.exists() || videoFile.length() == 0L) return
            val bytes = videoFile.readBytes()
            val encFile = File(videoFile.parentFile, "${videoFile.nameWithoutExtension}.mp4.enc")
            val ef = EncryptedFile.Builder(
                this, encFile, masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()
            ef.openFileOutput().use { it.write(bytes) }
            videoFile.delete()
            runOnUiThread {
                Toast.makeText(this, "動画を暗号化保存しました", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Encrypt video failed", e)
            runOnUiThread {
                Toast.makeText(this, "動画の暗号化に失敗", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun rotateBitmap(src: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return src
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
    }

    private fun saveEncryptedImage(bitmap: Bitmap) {
        try {
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, baos)
            val jpegBytes = baos.toByteArray()

            val dir = File(filesDir, "secure_images").apply { if (!exists()) mkdirs() }
            val file = File(dir, "IMG_${System.currentTimeMillis()}.jpg.enc")

            val encryptedFile = EncryptedFile.Builder(
                this, file, masterKey,
                EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
            ).build()

            encryptedFile.openFileOutput().use { out ->
                out.write(jpegBytes)
                out.flush()
            }

            runOnUiThread { Toast.makeText(this, "保存OK", Toast.LENGTH_SHORT).show() }
        } catch (e: Exception) {
            Log.e(TAG, "Encrypt failed", e)
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            // カメラ権限が取れていれば起動（マイクは任意）
            val cameraGranted = ContextCompat.checkSelfPermission(
                baseContext, Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            if (cameraGranted) startCamera()
            else {
                Toast.makeText(this, "カメラ権限が必要です", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // 画面を離れる時に録画中なら停止
        if (isRecording) stopRecording()
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

    companion object {
        private const val TAG = "SilentCamera"
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        )
        private const val KEY_BAR_COLOR = "bar_color"
        private const val KEY_PREVIEW_VISIBLE = "preview_visible"
        private val DEFAULT_BAR_COLOR = Color.parseColor("#66BB6A")
    }
}
