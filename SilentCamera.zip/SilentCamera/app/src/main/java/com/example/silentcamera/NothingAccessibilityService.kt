package com.example.silentcamera

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * 他アプリ使用中でも音量ボタンを検知するためのアクセシビリティサービス。
 *
 * 仕様:
 * - 音量UP/DOWN を横取りして短押し/長押しを判定
 * - 判定結果をMainActivityにブロードキャストで通知
 */
class NothingAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null
    private var pressingSince = 0L
    private var pressHandled = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP &&
            event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    pressingSince = System.currentTimeMillis()
                    pressHandled = false
                    longPressRunnable = Runnable {
                        if (!pressHandled) {
                            pressHandled = true
                            sendIntentToApp(ACTION_LONG_PRESS_START)
                        }
                    }
                    handler.postDelayed(longPressRunnable!!, 600)
                }
                return true
            }
            KeyEvent.ACTION_UP -> {
                longPressRunnable?.let { handler.removeCallbacks(it) }
                longPressRunnable = null
                if (pressHandled) {
                    sendIntentToApp(ACTION_LONG_PRESS_END)
                } else {
                    sendIntentToApp(ACTION_SHORT_PRESS)
                }
                pressHandled = false
                return true
            }
        }
        return false
    }

    private fun sendIntentToApp(action: String) {
        val intent = Intent(action).apply {
            setPackage(packageName) // 自アプリ限定
        }
        sendBroadcast(intent)
    }

    companion object {
        const val ACTION_SHORT_PRESS = "com.example.silentcamera.SHORT_PRESS"
        const val ACTION_LONG_PRESS_START = "com.example.silentcamera.LONG_PRESS_START"
        const val ACTION_LONG_PRESS_END = "com.example.silentcamera.LONG_PRESS_END"
    }
}
