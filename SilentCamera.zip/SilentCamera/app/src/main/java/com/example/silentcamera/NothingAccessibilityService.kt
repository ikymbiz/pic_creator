package com.example.silentcamera

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import androidx.localbroadcastmanager.content.LocalBroadcastManager

/**
 * 他アプリ使用中でも音量ボタンを検知するためのアクセシビリティサービス。
 *
 * 仕様:
 * - 音量UP/DOWN を横取りして短押し/長押しを判定
 * - 判定結果をMainActivityにLocalBroadcastで通知
 * - ただし、このアプリの録画中でない時は音量調整をブロックしない（イベントをOSに渡す）
 */
class NothingAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var longPressRunnable: Runnable? = null
    private var pressingSince = 0L
    private var pressHandled = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // このサービスは音量ボタン横取りが目的なので、通常のイベントは無視
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP &&
            event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return false
        }

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    pressingSince = System.currentTimeMillis()
                    pressHandled = false
                    // 600ms後に長押しと判定して録画開始ブロードキャストを送る
                    longPressRunnable = Runnable {
                        if (!pressHandled) {
                            pressHandled = true
                            sendIntentToApp(ACTION_LONG_PRESS_START)
                        }
                    }
                    handler.postDelayed(longPressRunnable!!, 600)
                }
                // このイベントを消費するかは「録画中かどうか」で決めたいが、
                // Service側では状態がわからないので、常にtrueにして録画や撮影の
                // トリガーに使う。音量調整したい場合はアクセシビリティをOFFにする運用。
                // ↓ただしユーザビリティを優先してACTION_DOWNは消費する（重複発火防止）
                return true
            }
            KeyEvent.ACTION_UP -> {
                longPressRunnable?.let { handler.removeCallbacks(it) }
                longPressRunnable = null
                val duration = System.currentTimeMillis() - pressingSince
                if (pressHandled) {
                    // 長押しで既に発火済み → UPでは「長押し終了」通知を送る
                    sendIntentToApp(ACTION_LONG_PRESS_END)
                } else {
                    // 短押しと判定
                    sendIntentToApp(ACTION_SHORT_PRESS)
                }
                pressHandled = false
                return true
            }
        }
        return false
    }

    private fun sendIntentToApp(action: String) {
        val intent = Intent(action)
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    companion object {
        const val ACTION_SHORT_PRESS = "com.example.silentcamera.SHORT_PRESS"
        const val ACTION_LONG_PRESS_START = "com.example.silentcamera.LONG_PRESS_START"
        const val ACTION_LONG_PRESS_END = "com.example.silentcamera.LONG_PRESS_END"
    }
}
